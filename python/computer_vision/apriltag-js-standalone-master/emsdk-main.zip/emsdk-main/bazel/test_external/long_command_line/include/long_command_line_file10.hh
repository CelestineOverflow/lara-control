#pragma once

void f10();
