#include "long_command_line_file20.hh"

#include <iostream>

void f20() { std::cout << "hello from f20()\n"; }
