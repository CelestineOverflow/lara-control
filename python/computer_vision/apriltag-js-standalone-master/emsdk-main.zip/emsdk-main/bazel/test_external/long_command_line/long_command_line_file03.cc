#include "long_command_line_file03.hh"

#include <iostream>

void f3() { std::cout << "hello from f3()\n"; }
