#include "long_command_line_file06.hh"

#include <iostream>

void f6() { std::cout << "hello from f6()\n"; }
