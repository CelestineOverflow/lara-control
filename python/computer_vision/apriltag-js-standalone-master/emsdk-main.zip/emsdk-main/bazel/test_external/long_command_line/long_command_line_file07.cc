#include "long_command_line_file07.hh"

#include <iostream>

void f7() { std::cout << "hello from f7()\n"; }
